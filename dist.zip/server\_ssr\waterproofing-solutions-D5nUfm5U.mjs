import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { l as services, o as ServiceDetailPage } from "./atharv-site-nihMsy2t.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/waterproofing-solutions-D5nUfm5U.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceDetailPage, { service: services[3] });
//#endregion
export { SplitComponent as component };
